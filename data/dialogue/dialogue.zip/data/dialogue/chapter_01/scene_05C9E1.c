#include "dialogue_macros.h"

/* ROM 0x0805C9E1 */
DIALOGUE_SCRIPT(0x0805C9E1, scene_05C9E1)
  TALK(SPEAKER_RECKER, SIDE_LEFT, EXPR_NEUTRAL,
      "A Krill Battleworm is dropping out of orbit. Sigma Team, follow my lead.")
END_DIALOGUE_SCRIPT()

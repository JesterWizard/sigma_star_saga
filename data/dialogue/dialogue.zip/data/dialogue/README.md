# Dialogue dump (vanilla reference)

Vanilla talk scripts extracted from `baserom.gba` as ygodm8-style C macros.

**Editable copy for in-game patches:** [`src_custom/dialogue/`](../../src_custom/dialogue/).
Full write-up: [`documentation/dialogue/`](../../documentation/dialogue/).

## Regenerate (overwrites this tree only)

```bash
python3 tools/extract_dialogue.py
```

To refresh the editable copy from vanilla (destroys local edits):

```bash
rm -rf src_custom/dialogue
cp -a data/dialogue src_custom/dialogue
```

## Layout

Seven banks from the pointer table at `0x24EA6C` (ids 0–464). Each
`scene_XXXXXX.c` is one `#` entry; `XXXXXX` is the file offset of that `#`.
Empty stubs are kept as `EMPTY()` so script IDs stay aligned.
